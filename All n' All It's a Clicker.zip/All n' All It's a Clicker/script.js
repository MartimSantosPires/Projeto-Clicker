// Game State Variables
let cash = 0;
let shards = 0;
let clickPower = 1;
let passiveShardRate = 0;

function manualClick() {
    cash += clickPower;
    updateUI();
}

function buyUpgrade() {
    let cost = 50;
    if (cash >= cost) {
        cash -= cost;
        passiveShardRate += 1;
        updateUI();
    } else {
        alert("Not enough cash, bro! You need " + cost + " cash.");
    }
}

function updateUI() {
    document.getElementById("cash-display").innerHTML = cash;
    document.getElementById("shard-display").innerHTML = shards;
    document.getElementById("cps-display").innerHTML = passiveShardRate;
}

let gameLoop = setInterval(function() {
    shards += passiveShardRate;
    updateUI();
}, 1000);

function openTab(tabId) {
    let panes = document.querySelectorAll('.tab-pane');
    panes.forEach(pane => {
        pane.style.display = 'none';
    });

    let buttons = document.querySelectorAll('.tab-btn');
    buttons.forEach(btn => {
        btn.classList.remove('active');
    });

    document.getElementById(tabId).style.display = 'block';
    document.getElementById(`btn-${tabId}`).classList.add('active');
}